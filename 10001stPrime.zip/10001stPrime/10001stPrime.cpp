#include <iostream>
#include <vector>

int isPrime(int f){
    if (f == 2 || f == 3) {
      //it is prime
      return 1;
    }

    if (f <= 1 || f % 2 == 0 || f % 3 == 0) {
      //it is not prime
      return 0;

    }

    for (int i = 5; i * i <= f; i += 6)
    {
      if (f % i == 0 || f % (i + 2) == 0) {
        //it is not prime
        return 0;
      }
    }

    //it is prime
    return 1;
}

int main() {
  std::string whichPrime;
  std::cin >> whichPrime;
  int i = 0;
  std::vector<int> primes = {};
  while(true) {
    ++i;
    if (isPrime(i)) {
      primes.push_back(i);
    }
    if (primes.size() == std::stoi(whichPrime, nullptr)) {
      std::cout << primes.back() << "\n";
      return 0;
    }
  }
  return 0;
}
