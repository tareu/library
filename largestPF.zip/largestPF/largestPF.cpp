#include <iostream>
#include <vector>

int isPrime(int f){
    if (f == 2 || f == 3) {
      //it is prime
      return 1;
    }
    
    if (f <= 1 || f % 2 == 0 || f % 3 == 0) {
      //it is not prime
      return 0;
      
    }
    
    for (int i = 5; i * i <= f; i += 6)
    {
      if (f % i == 0 || f % (i + 2) == 0) {
        //it is not prime
        return 0;
      }
    }
    
    //it is prime
    return 1;
}

int main(){
  std::vector<long int> factors = {};
  long int factee;
  std::cin >> factee;
  long int potentialFactor = 1;
  while (potentialFactor * potentialFactor <= factee) {
    if (factee % potentialFactor == 0) {
      factors.push_back(potentialFactor);
      if (factee/potentialFactor != potentialFactor) {
        factors.push_back(factee/potentialFactor);
      }
    }
    ++potentialFactor;
  }
  
  std::vector<long int> primeFactors = {};

  for (long int f : factors) {
    if (isPrime(f) == 1) {
      primeFactors.push_back(f);
    }
  }
  
  long int largestPF = 0;
  for (long int pF : primeFactors) {
    if (pF > largestPF) {
      largestPF = pF;
    }
  }
  std::cout << largestPF << "\n";
}
