#include <iostream>

int main()
{
  int sum = 0;
  int max;
  int OfX;
  int OfY;
  std::cin >> OfY;
  std::cin >> OfX;
  std::cin >> max;
  int multiple = 0;
  for (int i = 0; i < max; i++)
  {
    multiple = 0;
    if (i % OfY == 0)
    {
      multiple = 1;
    }
    if (i % OfX == 0)
    {
      multiple = 1;
    }
    if (multiple == 1)
    {
      sum = sum + i;
    }
  } 
  
  std::cout << sum << "\n";
  return 0;
}
