#include <iostream>
#include <vector>
#include <string>

int main() {
  std::vector<int> palindromes = {};
  int max;
  std::cin >> max;
  for (int i = 1; i < max; ++i) {
    for (int j = 1; j < max; ++j) {
      std::string product = std::to_string(i * j);
      std::string reversedProduct = product;
      for (int k = 0; k < product.length(); ++k) {
        reversedProduct[k] = product[product.length() - k - 1];
      }
      
      if (product.compare(reversedProduct) == 0) {
        palindromes.push_back(std::stoi(product, nullptr));
      }
    }
  }
  int largestPalindrome = 0;
  for (int x : palindromes) {
    if (x > largestPalindrome) {
      largestPalindrome = x;
    }
  }
  
  std::cout << largestPalindrome << "\n";
}
