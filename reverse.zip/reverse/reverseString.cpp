#include <iostream>
#include <string>
#include <vector>

int main() {
	std::string wordsIn;
	std::getline(std::cin, wordsIn);
	std::vector<std::string> wordsResult;
	std::string reversedWord;
	int count = 0;

	for (char x : wordsIn) {
		count++;
		if (x == 32) {
			wordsResult.push_back(reversedWord);
			reversedWord = "";
			continue;
		}
		if (count == wordsIn.length()) {
			reversedWord.insert(reversedWord.begin(), x);
			wordsResult.insert(wordsResult.begin(), reversedWord);
			reversedWord = "";
			continue;
		}
		reversedWord.insert(reversedWord.begin(), x);
	}

	
	count = 0;	

	for (std::string x : wordsResult){
		count++;
		for (char y : x) {
			std::cout << y;
		}

		if (wordsResult.size() != count) {
			std::cout << " ";
		}

	}
	std::cout << "\n";
	return 0;
}
