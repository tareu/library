#include <iostream>
#include <vector>
#include <string>

int main() {
  std::string number;
  int digitsLength;
  std::cin >> number;
  std::cin >> digitsLength;
  long int whichDigits = 0;
  std::vector<std::string> numberCollection;
  while (number.length() > digitsLength + whichDigits) {

    std::string adjacentDigits;

    for (int i = 0; i < digitsLength; ++i) {
      adjacentDigits.push_back(number[i + whichDigits]);
    }

    numberCollection.push_back(adjacentDigits);

    ++whichDigits;
  }

  long int largestProduct = 0;
  for (std::string n : numberCollection) {
    long int product = 1;
    for (int i = 0; i < digitsLength; ++i) {
      char partOfNumber = n[i];
      product = product * std::atoi(&partOfNumber);
    }
    if (product > largestProduct){
      largestProduct = product;
    }
  }

  std::cout << largestProduct << "\n";

  return 0;
}
