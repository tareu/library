#include <iostream>
#include <vector>

int main() {
  int max;
  std::cin >> max;
  int term1 = 1;
  int term2 = 2;
  int newTerm = 0;
  int finished = 0;

  std::vector<int> v = {1, 2};

  while(finished == 0) {
    newTerm = term1 + term2;
    term1 = term2;
    term2 = newTerm;
    if (newTerm > max) {
      finished = 1;
    }
    if (newTerm < max) {
      v.push_back(newTerm);
    }
  }
  int sum = 0;
  for (int x : v) {
    if (x % 2 == 0) {
      sum = sum + x;
    }
  }

  std::cout << sum << "\n";

  return 0;
}
