#include<iostream>
#include<string>
#include<memory>
#include<vector>
#include<concepts>


class MyException : public std::runtime_error
{
public:
  MyException(const std::string& msg) : std::runtime_error{msg} {}
};

template <typename T>
class Matrix {

private:
  std::vector<int> v;

public:
  long int numberOfElements = 1;
  
  int operator[](int x, int y)
  {
    return 1;
  }

  Matrix(std::initializer_list<int> l) : v(l) {

    for (int x : v) {
      if (x < 1) {
        throw MyException{"tried to make a dimension with 0 or negative number of elements"};
      }
      numberOfElements = numberOfElements * x;
    }
    

  }

};

int main() {
  Matrix<int> m {1, 3, 4};
  m[1, 1];

  std::cout << m.numberOfElements << " " << m[1, 1];
  std::cout << "\n";

  return 0;

}
