#include<iostream>

int main(){
    int f;
    std::cin >> f;
    if (f == 2 || f == 3) {
      //it is prime
      std::cout << 1 << "\n";
      return 0;

    }

    if (f <= 1 || f % 2 == 0 || f % 3 == 0) {
      //it is not prime
      std::cout << 0 << "\n";
      return 0;

    }

    for (int i = 5; i * i <= f; i += 6)
    {
      if (f % i == 0 || f % (i + 2) == 0) {
        //it is not prime
        std::cout << 0 << "\n";
        return 0;
      }
    }

    //it is prime
    std::cout << 1 << "\n";
    return 0;
}
