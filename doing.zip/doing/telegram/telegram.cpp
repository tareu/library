#include <iostream>
#include <fstream>
#include <string>
#include <vector>
int main() 
{
  std::ifstream infile("text.txt");
  std::string line;
  std::getline(infile, line);
  std::vector<std::string> newLine;
  std::string word;
  for (auto c : line)
  {
    if (c != ' ')
    {
      word.push_back(c);
    }
    if (c == ' ')
    {
      newLine.push_back(word);
      word.clear();
    }
  }
  std::string printLine;
  std::vector<std::string> finalText;
  for (auto w : newLine)
  {
    if (printLine.length() < 40)
    {
      if (printLine.length() > 1)
      {
        printLine.push_back(' ');
      }
      for (auto c : w)
      {
        printLine.push_back(c);
      }
    }
    if (printLine.length() >= 40)
    {
      printLine.append("\n");
      finalText.push_back(printLine);
      printLine.clear();
    }
  }
  for (auto text : finalText)
  {
    std::cout << text;
  }
  std::cout << "\n";
  return 0;
}
