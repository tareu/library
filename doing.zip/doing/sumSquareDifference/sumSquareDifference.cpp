#include<iostream>
#include<vector>

int main() {
  int sumOfSquares = 0;
  int sum = 0;
  int sqOfSum = 0;
  int difference = 0;
  for (int i = 0; i < 100; ++i) {
    sumOfSquares = sumOfSquares + ((i + 1) * (i + 1));
    sum = sum + (i + 1);
  }
  sqOfSum = sum * sum;
  difference = sqOfSum - sumOfSquares;
  std::cout << difference << "\n";
  return 0;
}
