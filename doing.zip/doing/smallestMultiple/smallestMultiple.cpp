#include <iostream>

int main() {

  bool numberFound = false;
  int testNumber = 0;

  while(numberFound == false) {
    testNumber = testNumber + 20;
    numberFound = true;
    for (int i = 0; i < 20; ++i) {
      if ((testNumber % (i + 1)) != 0) {
        numberFound = false;
        break;
      } 
    }
  }

  std::cout << testNumber << "\n";

}
